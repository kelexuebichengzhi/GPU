#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <omp.h>

#include "NBody.h"
#include "NBodyVisualiser.h"

#define USER_NAME "test"		//replace with your username

void print_help();
void step(void);
int argparse(int argc, char** argv);

const int num_threads = 12;

int N = 0, D = 0, iter = 0;
MODE M;
FILE* file = NULL;
nbody* v = NULL;
float* ax = NULL;
float* ay = NULL;
float* m = NULL;
float* act = NULL;
float* p = NULL;

inline float rand_01() {
	int v1 = rand() & 0x3fff;
	if (v1 < 0) v1 += 0x4000;
	float ret = v1;
	ret /= 0x4000;
	return ret;
}

int read_file() {
	int c = 0;
	char buf[4096] = { 0 };
	const float default_m = 1.0 / (float)N;
	nbody tmp;
	char t[5][32];
	while (fgets(buf, 4096, file)) {
		if (buf[0] == '#') {
			//skip to start of next line
			continue;
		}
		else {
			if (c >= N) {
				return N + 1;
			}
			sscanf(buf, "%32[^,],%32[^,],%32[^,],%32[^,],%32[^,]", t[0], t[1], t[2], t[3], t[4]);
			tmp.x = atof(t[0]);
			tmp.y = atof(t[1]);
			tmp.vx = atof(t[2]);
			tmp.vy = atof(t[3]);
			tmp.m = atof(t[4]);
			if (tmp.x == 0) tmp.x = rand_01();
			if (tmp.y == 0) tmp.y = rand_01();
			if (tmp.m == 0) tmp.m = default_m;
			v[c] = tmp;
			m[c] = tmp.m;
			c++;
		}
	}
	return c;
}

int fill_rand() {
	const float default_m = 1.0 / (float)N;
	for (int i = 0; i < N; i++) {
		v[i].x = rand_01();
		v[i].y = rand_01();
		v[i].vx = 0;
		v[i].vy = 0;
		v[i].m = default_m;
		m[i] = default_m;
	}
	return 0;
}

int main(int argc, char* argv[]) {

	// Processes the command line arguments
	if (argparse(argc, argv) != 0) {
		return 0;
	}
	if (M == OPENMP) {
		omp_set_num_threads(num_threads);
	}

	// Allocate any heap memory
	v = (nbody*)malloc(N * sizeof(nbody));
	// Since step() access <m> a lot and <m> is constant, we seperate it.
	// Updating (x,y,vx,vy) may force re-load of nbody struct into cache.
	// If we access <m> from nbody struct, CPU may need to wait for re-load.
	m = (float*)malloc(N * sizeof(float));
	ax = (float*)malloc(N * sizeof(float));
	ay = (float*)malloc(N * sizeof(float));
	act = (float*)malloc(D * D * sizeof(float));
	p = (float*)malloc(N * N * sizeof(float));
	if (v == NULL || m == NULL || ax == NULL || ay == NULL || act == NULL || p == NULL) {
		printf("%s: Malloc FAIL!\n", __func__);
		return -1;
	}
	memset(act, 0, D * D * sizeof(float));

	// Depending on program arguments, either read initial data from file or generate random data.
	srand(time(NULL));
	if (file) {
		if (read_file() != N) {
			printf("%s: Numbers in file not equal to %d provided in command line parameter!\n", __func__, N);
			return -1;
		}
	}
	else {
		// create random data
		fill_rand();
	}

	// Depending on program arguments, either configure and start the visualiser or 
	// perform a fixed number of simulation steps (then output the timing results).
	if (iter == 0) {
		// visualize
		initViewer(N, D, M, step);
		setNBodyPositions(v);
		setHistogramData(act);
		//setActivityMapData(act);
		startVisualisationLoop();
	}
	else {
		clock_t start = clock();
		for (int i = 0; i < iter; i++) {
			step();
		}
		clock_t end = clock() - start;
		printf("\n");
		long msec = end * 1000 / CLOCKS_PER_SEC;
		printf("\tExecution time %0d seconds %0d milliseconds\n", msec / 1000, msec % 1000);
		free(v);
		free(m);
		free(ax);
		free(ay);
		free(act);
		free(p);
		v = NULL;
		m = NULL;
		ax = NULL;
		ay = NULL;
		act = NULL;
		p = NULL;
		return 0;
	}

	return 0;
}

void step_CPU(void) {
	const float e2 = SOFTENING * SOFTENING;
	const float a1 = 1.0 / (N + 0.0);
	//TODO: Perform the main simulation of the NBody system
	// p[i][j]=((x[j]-x[i])^2+(y[j]-y[i])^2+e^2)^(-3/2)
	// q[i][j]=m[j]*p[i][j]
	// ax[i]/G=sum_{j=1}^{N} (x[j]-x[i])m[j]*p[i][j]=sum_{j=1}^{N} x[j]*q[i][j] - x[i] * sum_{j=1}^{N} q[i][j]
	// ay[i]/G=sum_{j=1}^{N} (y[j]-y[i])m[j]*p[i][j]=sum_{j=1}^{N} y[j]*q[i][j] - y[i] * sum_{j=1}^{N} q[i][j]
	for (int i = 0; i < N; i++) {
		for (int j = 0; j <= i; j++) {
			float d2 = (v[i].x - v[j].x) * (v[i].x - v[j].x) + (v[i].y - v[j].y) * (v[i].y - v[j].y) + e2;
			d2 = 1 / d2;
			d2 *= sqrtf(d2);
			p[i * N + j] = m[j] * d2;
			p[j * N + i] = m[i] * d2;
		}
	}
	memset(act, 0, D * D * sizeof(float));
	for (int i = 0; i < N; i++) {
		float sx = 0, sy = 0, ss = 0;
		for (int j = 0; j < N; j++) {
			sx += v[j].x * p[i * N + j];
			sy += v[j].y * p[i * N + j];
			ss += p[i * N + j];
		}
		ax[i] = G * (sx - v[i].x * ss);
		ay[i] = G * (sy - v[i].y * ss);
		v[i].x += dt * v[i].vx;
		v[i].y += dt * v[i].vy;
		int nx = v[i].x * D, ny = v[i].y * D;
		// update the <act> array, locating by the new (x,y)
		if (nx >= 0 && nx < D && ny >= 0 && ny < D) act[ny * D + nx] += a1;
		v[i].vx += dt * ax[i];
		v[i].vy += dt * ay[i];
		//printf("\t%0d:\tx=%0f\ty=%0f\tvx=%0f\tvy=%0f\tax=%0f\tay=%0f\tm=%f\n", i, v[i].x, v[i].y, v[i].vx, v[i].vy, ax[i], ay[i], v[i].m);
	}
}

void step_OMP(void) {
	const float e2 = SOFTENING * SOFTENING;
	const float a1 = 1.0 / (N + 0.0);
	const int _N = N;
	int i = 0, j = 0;
	memset(act, 0, D * D * sizeof(float));
	// no data dependcy in the loop below
	// use dynamic schedule here, since loop length varies.
	// although loop length decreases with loop varibale increasing,
	// guided schedule does not precisly fit this decrease relationship.
	// compare the following 3 schedules: N=4096, iter=1024, max_threads=12
//#pragma omp parallel for // 57s 550ms
//#pragma omp parallel for schedule(guided) // 50s 40ms
#pragma omp parallel for schedule(dynamic) // 30s 440ms
	for (i = 0; i < _N; i++) {
#pragma omp parallel for
		// range of omp parallel for must be same, that is, constant.
		for (j = 0; j < _N; j++) {
			// we do not use break here, since jump out of parallel for is not allowed.
			if (j > i) continue; 
			float d2 = (v[i].x - v[j].x) * (v[i].x - v[j].x) + (v[i].y - v[j].y) * (v[i].y - v[j].y) + e2;
			d2 = 1 / d2;
			d2 *= sqrtf(d2);
			p[i *_N+ j] = m[j] * d2;
			p[j *_N+ i] = m[i] * d2;
		}
	}
	// also no data dependcy in the loop below
	// since length of all loop are the same, no special schedule required here
#pragma omp parallel for
	for (i = 0; i < _N; i++) {
		float sx = 0, sy = 0, ss = 0;
		// attention the reduction here
#pragma omp parallel for reduction(+:sx,sy,ss)
		for (j = 0; j < _N; j++) {
			sx += v[j].x * p[i *_N+ j];
			sy += v[j].y * p[i *_N+ j];
			ss += p[i *_N+ j];
		}
		// omp sections could be applied here, but only 2 sections work.
		// We do not use sections here, since cost of thread creation and join 
		// may be more than what saved by parallel sections.
		// Also, the update order is important, you first update (x,y), then (vx,vy)
		ax[i] = G * (sx - v[i].x * ss);
		ay[i] = G * (sy - v[i].y * ss);
		v[i].x += dt * v[i].vx;
		v[i].y += dt * v[i].vy;
		int nx = v[i].x * D, ny = v[i].y * D;
		if (nx >= 0 && nx < D && ny >= 0 && ny < D) act[ny * D + nx] += a1;
		v[i].vx += dt * ax[i];
		v[i].vy += dt * ay[i];
		//printf("\t%0d:\tx=%0f\ty=%0f\tvx=%0f\tvy=%0f\tax=%0f\tay=%0f\tm=%f\n", i, v[i].x, v[i].y, v[i].vx, v[i].vy, ax[i], ay[i], v[i].m);
	}
}

inline void step(void)
{
	if (M == CPU) step_CPU();
	else step_OMP();
}

int argparse(int argc, char** argv) {
	if (argc != 4 && argc != 6 && argc != 8) {
		print_help();
		return -1;
	}
	N = atoi(argv[1]);
	if (N <= 0) {
		printf("%s: incorrect number of bodies: %d\n", __func__, N);
		return -1;
	}
	D = atoi(argv[2]);
	if (D <= 0) {
		printf("%s: incorrect dimension of the activity grid: %d\n", __func__, D);
		return -1;
	}
	if (strncmp(argv[3], "CPU", 3) == 0) {
		M = CPU;
	}
	else if (strncmp(argv[3], "OPENMP", 5) == 0) {
		M = OPENMP;
	}
	else {
		printf("%s: incorrect MODE: %s\n", __func__, argv[3]);
		return -1;
	}
	if (argc == 4) return 0;
	else if (argc == 6) {
		if (strncmp("-i", argv[4], 2) == 0) {
			iter = atoi(argv[5]);
			if (iter <= 0) {
				printf("%s: incorrect iterations: %d\n", __func__, iter);
				return -1;
			}
			return 0;
		}
		else if (strncmp("-f", argv[4], 2) == 0) {
			file = fopen(argv[5], "r");
			if (file == NULL) {
				printf("%s: file %s does not exist!\n", __func__, argv[5]);
				return -1;
			}
			return 0;
		}
		else {
			printf("%s: bad parameters: %s %s\n", __func__, argv[4], argv[5]);
			return -1;
		}
	}
	else if (argc == 8) {
		if (strncmp("-i", argv[4], 2) == 0) {
			iter = atoi(argv[5]);
			if (iter <= 0) {
				printf("%s: incorrect iterations: %d\n", __func__, iter);
				return -1;
			}
			if (strncmp("-f", argv[6], 2) == 0) {
				file = fopen(argv[7], "r");
				if (file == NULL) {
					printf("%s: file %s does not exist!\n", __func__, argv[7]);
					return -1;
				}
				return 0;
			}
			else {
				printf("%s: bad parameters: %s %s\n", __func__, argv[6], argv[7]);
				return -1;
			}
		}
		else if (strncmp("-f", argv[4], 2) == 0) {
			file = fopen(argv[5], "r");
			if (file == NULL) {
				printf("%s: file %s does not exist!\n", __func__, argv[5]);
				return -1;
			}
			if (strncmp("-i", argv[6], 2) == 0) {
				iter = atoi(argv[7]);
				if (iter <= 0) {
					printf("%s: incorrect iterations: %d\n", __func__, iter);
					return -1;
				}
				return 0;
			}
			else {
				printf("%s: bad parameters: %s %s\n", __func__, argv[6], argv[7]);
				return -1;
			}
		}
		else {
			printf("%s: bad parameters: %s %s %s %s\n", __func__, argv[4], argv[5], argv[6], argv[7]);
			return -1;
		}
	}
	return -1;
}

void print_help(){
	printf("nbody_%s N D M [-i I] [-i input_file]\n", USER_NAME);

	printf("where:\n");
	printf("\tN                Is the number of bodies to simulate.\n");
	printf("\tD                Is the integer dimension of the activity grid. The Grid has D*D locations.\n");
	printf("\tM                Is the operation mode, either  'CPU' or 'OPENMP'\n");
	printf("\t[-i I]           Optionally specifies the number of simulation iterations 'I' to perform. Specifying no value will use visualisation mode. \n");
	printf("\t[-f input_file]  Optionally specifies an input file with an initial N bodies of data. If not specified random data will be created.\n");
}
